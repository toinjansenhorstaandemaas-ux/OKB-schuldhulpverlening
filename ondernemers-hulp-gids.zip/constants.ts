
import { Question } from './types';

export const QUESTIONNAIRE_DATA: Record<number, Question> = {
  1: {
    id: 1,
    text: "Is de ondernemer woonachtig in Nederland",
    options: [
      { id: "1", text: "Ja", nextQuestionId: 2, action: "De gemeente kan om hulp gevraagd worden bij schuldsanering" },
      { id: "2", text: "Nee", nextQuestionId: 2, action: "De gemeente kan niet om hulp gevraagd worden bij schuldsanering" }
    ]
  },
  2: {
    id: 2,
    text: "Heeft de ondernemer nog een actieve boekhouder",
    options: [
      { id: "1", text: "Ja", nextQuestionId: 4 },
      { id: "2", text: "Nee", nextQuestionId: 3 }
    ]
  },
  3: {
    id: 3,
    text: "Wie kan hulp bieden bij de boekhouder",
    options: [
      { id: "1", text: "Over Rood (aanvraag door gemeente)", nextQuestionId: 5, action: "Vraag gemeente om contact op te nemen met Over Rood" },
      { id: "2", text: "MKB Santos", nextQuestionId: 5, action: "Neem contact op te met MKB Santos" },
      { id: "3", text: "Thuisadministratie", nextQuestionId: 5, action: "Neem contact op te met Thuisadministratie" }
    ]
  },
  4: {
    id: 4,
    text: "Is de onderneming nog actief",
    options: [
      { id: "1", text: "Ja", nextQuestionId: 5 },
      { id: "2", text: "Nee", nextQuestionId: 9 }
    ]
  },
  5: {
    id: 5,
    text: "Kan ondernemer aantonen dat hij/zij meer dan 1225 per jaar in onderneming werkt",
    options: [
      { id: "1", text: "Ja", nextQuestionId: 6, action: "Info: Persoon is ondernemer volgens de belastingdienst" },
      { id: "2", text: "Nee", nextQuestionId: 11, action: "Info: persoon is geen ondernemer volgens de belastingdienst" }
    ]
  },
  6: {
    id: 6,
    text: "Heeft de persoon een inkomen uit onderneming beneden bijstandsniveau",
    options: [
      { id: "1", text: "Ja", nextQuestionId: 7, action: "Vraag BBZ aan" },
      { id: "2", text: "Nee", nextQuestionId: 7 }
    ]
  },
  7: {
    id: 7,
    text: "Wil de ondernemer de onderneming voortzetten",
    options: [
      { id: "1", text: "Ja", nextQuestionId: 8 },
      { id: "2", text: "Nee", nextQuestionId: 10 }
    ]
  },
  8: {
    id: 8,
    text: "Is de onderneming levensvatbaar na schuldsanering",
    options: [
      { 
        id: "1", 
        text: "Ja", 
        nextQuestionId: 9, 
        action: "Ondernemersplan voor voortzetting onderneming maken. Cashbehoefte nodig om onderneming voor te zetten bepalen. Zoek organisatie die cashbehoefte wil financieren (Gebruik financieringswijzer KvK). Ga na of je bedrijfskrediet kunt aanvragen in kader van BBZ regeling" 
      },
      { 
        id: "2", 
        text: "Nee", 
        nextQuestionId: 9, 
        action: "Ga schuldsaneringstraject in en voorkom faillissement. Onderneming uitschrijven uit Kamer van Koophandel. Alle belastingaangiftes indienen tot het moment van uitschrijving uit KvK. Informeren belastingdienst over uitschrijving uit KvK" 
      }
    ]
  },
  9: {
    id: 9,
    text: "Heeft de ondernemer een BV en geen persoonlijke aansprakelijkheid voor schulden in de BV",
    options: [
      { id: "1", text: "Ja", nextQuestionId: 10, action: "Vraag faillissement aan" },
      { id: "2", text: "Nee", nextQuestionId: 10, action: "Ga schuldsaneringstraject in en voorkom faillissement" }
    ]
  },
  10: {
    id: 10,
    text: "Heeft de ondernemer voorlopige aanslagen ontvangen",
    options: [
      { id: "1", text: "Ja", nextQuestionId: 11, action: "Maak bezwaar tegen openstaande voorlopige aanslagen indien niet correct en dien correcte aangiften in" },
      { id: "2", text: "Nee", nextQuestionId: 11 }
    ]
  },
  11: {
    id: 11,
    text: "Is de persoon in loondienst",
    options: [
      { id: "1", text: "De persoon is in loondienst", nextQuestionId: 12 },
      { id: "2", text: "De persoon is nog niet in loondienst", nextQuestionId: 12 }
    ]
  },
  12: {
    id: 12,
    text: "Heeft de persoon alleen inkomsten uit onderneming beneden bijstandniveau",
    options: [
      { id: "1", text: "Ja", nextQuestionId: 14, action: "Vraag bij de Gemeente BBZ aan" },
      { id: "2", text: "Nee", nextQuestionId: 16 }
    ]
  },
  13: {
    id: 13,
    text: "Heeft de persoon alleen inkomen uit loondienst beneden bijstandsniveau",
    options: [
      { id: "1", text: "Ja", nextQuestionId: 16, action: "Vraag bijstand aan bij de gemeente" },
      { id: "2", text: "Nee", nextQuestionId: 16 }
    ]
  },
  14: {
    id: 14,
    text: "Is de ondernemer meer dan 10 jaar actief met de onderneming en ouder dan 57 jaar",
    options: [
      { id: "1", text: "Ja", nextQuestionId: 15, action: "BBZ kan mogelijk verstrekt worden als een gift" },
      { id: "2", text: "Nee", nextQuestionId: 15, action: "BBZ zal als lening verstrekt worden" }
    ]
  },
  15: {
    id: 15,
    text: "Is de aanvraag voor BBZ goedgekeurd",
    options: [
      { id: "1", text: "Ja", nextQuestionId: 16, action: "Inkomenssteun van 12 maanden die twee keer 12 maanden verlengd kan worden. BBZ is een lening die binnen 10 jaar afgelost moet worden of gift" },
      { id: "2", text: "Nee", nextQuestionId: 16, action: "Ga na hoe de ondernemer geld om te leven kan verkrijgen" }
    ]
  },
  16: {
    id: 16,
    text: "Is nog een mogelijkheid om niet kritische uitgaven te verlagen ?",
    options: [
      { id: "1", text: "Ja", nextQuestionId: 17, action: "Identificeer welke uitgaven verlaagd kunnen worden en neem actie" },
      { id: "2", text: "Nee", nextQuestionId: 17 }
    ]
  },
  17: {
    id: 17,
    text: "Wie kan helpen bij de schuldsanering",
    options: [
      { id: "1", text: "De ondernemer regelt schulden zelf", nextQuestionId: 18, action: "De ondernemer is verantwoordelijk om tot een regeling te komen met de schuldeisers" },
      { id: "2", text: "Gemeente biedt schuldhulpverlening aan in eigen beheer", nextQuestionId: 19, action: "Vraag schuldhulp aan bij de Gemeente" },
      { id: "3", text: "Gemeente biedt geen schuldhulpverlenining aan in eigen beheer", nextQuestionId: 19, action: "Vraag Gemeente om een derde partij voor schuldhulp te identificeren" }
    ]
  },
  18: {
    id: 18,
    text: "Ga jij (OKB) helpen met schuldhulp ?",
    options: [
      { 
        id: "1", 
        text: "Ja", 
        nextQuestionId: 20, 
        action: "Maak een overzicht van alle schulden en lopende afbetalingsregelingen. Bepaal hoeveel geld er per maand beschikbaar is voor afbetaling schulden. Probeer tot een minnelijke schikking te komen met crediteuren. Probeer tot een regeling te komen over schulden met de belastingdienst" 
      },
      { id: "2", text: "Nee", nextQuestionId: "END", action: "Probeer een partij te vinden die kan helpen bij schuldhulpverlening" }
    ]
  },
  19: {
    id: 19,
    text: "Biedt de gemeente schuldhulpverlening aan in eigen beheer or via een derde partij",
    options: [
      { id: "1", text: "Ja", nextQuestionId: 21, action: "Gemeente of derde partij probeert met crediteuren tot een minnelijke schikking te komen" },
      { id: "2", text: "Nee", nextQuestionId: 23, action: "Identificeer een andere partij die hulp kan bieden bij schuldsanering" }
    ]
  },
  20: {
    id: 20,
    text: "Is het de ondernemer gelukt om tot een vrijwillige schuldsanering en afbetalingsregeling te komen met de crediteuren",
    options: [
      { id: "1", text: "Ja", nextQuestionId: 23, action: "Documenteer de schuldsaneringsafspraken en volg de uitvoering ervan op" },
      { id: "2", text: "Nee", nextQuestionId: 21, action: "Vraag hulp aan de gemeente of a derde partij om te helpen met de schuldsanering" }
    ]
  },
  21: {
    id: 21,
    text: "Is het de gemeente of de derde partij gelukt om tot een minnelijke schikking te komen",
    options: [
      { id: "1", text: "Ja", nextQuestionId: 23, action: "De gemeente of derde partij documenteert de schuldsaneringsafspraken en volg de uitvoering ervan op" },
      { id: "2", text: "Nee", nextQuestionId: 22, action: "Verkrijg verklaring van de gemeente (B&W) dat minnelijke schikking niet mogelijk is. Vraag rechter om de WSNP toe te passen" }
    ]
  },
  22: {
    id: 22,
    text: "Wordt de WNSP van toepassing verklaart door de rechter",
    options: [
      { id: "1", text: "Ja", nextQuestionId: "END", action: "Rechter besluit tot moratorium van maximaal 6 maanden om tot een minnelijke schikking te komen" },
      { id: "2", text: "Nee", nextQuestionId: 23, action: "Schakel een OKB collega in met veel ervaring met schuldsanering" },
      { id: "3", text: "(Nog) niet van toepassing", nextQuestionId: 23 }
    ]
  },
  23: {
    id: 23,
    text: "Einde van de vragenlijst",
    options: []
  }
};
