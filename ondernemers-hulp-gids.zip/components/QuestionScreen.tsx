
import React from 'react';
import { Question, Option } from '../types';

interface QuestionScreenProps {
  question: Question;
  onAnswer: (option: Option) => void;
  onBack: () => void;
  canGoBack: boolean;
}

const QuestionScreen: React.FC<QuestionScreenProps> = ({ question, onAnswer, onBack, canGoBack }) => {
  return (
    <div className="p-8 sm:p-12">
      <div className="mb-8">
        <span className="inline-block px-3 py-1 bg-blue-50 text-blue-600 text-xs font-bold rounded-full uppercase tracking-wider mb-4">
          Vraag {question.id}
        </span>
        <h2 className="text-2xl font-bold text-slate-800 leading-snug">
          {question.text}
        </h2>
      </div>

      <div className="space-y-4">
        {question.options.map((option) => (
          <button
            key={option.id}
            onClick={() => onAnswer(option)}
            className="w-full text-left p-5 rounded-2xl border-2 border-slate-100 hover:border-blue-500 hover:bg-blue-50 transition-all duration-200 group flex items-center justify-between"
          >
            <span className="text-lg font-medium text-slate-700 group-hover:text-blue-700">{option.text}</span>
            <svg className="w-5 h-5 text-slate-300 group-hover:text-blue-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
            </svg>
          </button>
        ))}
        
        {question.options.length === 0 && (
           <button
             onClick={() => onAnswer({ id: 'finish', text: 'Afronden', nextQuestionId: 'END' })}
             className="w-full py-4 bg-blue-600 text-white rounded-2xl font-bold hover:bg-blue-700 shadow-lg shadow-blue-200 transition-all"
           >
             Bekijk Samenvatting
           </button>
        )}
      </div>

      {canGoBack && (
        <div className="mt-12 flex justify-start">
          <button
            onClick={onBack}
            className="flex items-center text-slate-400 hover:text-slate-600 font-medium text-sm transition-colors"
          >
            <svg className="w-4 h-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
            </svg>
            Vorige vraag
          </button>
        </div>
      )}
    </div>
  );
};

export default QuestionScreen;
