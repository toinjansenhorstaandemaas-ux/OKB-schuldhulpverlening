
import React from 'react';
import { AnswerRecord } from '../types';

interface SummaryScreenProps {
  history: AnswerRecord[];
  onReset: () => void;
}

const SummaryScreen: React.FC<SummaryScreenProps> = ({ history, onReset }) => {
  return (
    <div className="p-6 sm:p-10">
      <div className="text-center mb-10">
        <div className="bg-green-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
          <svg className="w-8 h-8 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
          </svg>
        </div>
        <h2 className="text-3xl font-extrabold text-slate-900">Advies Overzicht</h2>
        <p className="text-slate-500 mt-2">Een overzicht van uw antwoorden en de bijbehorende acties.</p>
      </div>

      <div className="mb-10 overflow-hidden border border-slate-200 rounded-2xl shadow-sm">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200">
                <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Vraag</th>
                <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Antwoord</th>
                <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Actie / Opmerking</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {history.map((record, idx) => (
                <tr key={idx} className="hover:bg-slate-50 transition-colors">
                  <td className="px-6 py-5 text-sm font-semibold text-slate-800 align-top max-w-[200px] sm:max-w-xs">
                    <span className="text-slate-400 text-[10px] block mb-1">VRAAG {record.questionId}</span>
                    {record.questionText}
                  </td>
                  <td className="px-6 py-5 text-sm align-top">
                    <div className="inline-flex items-center text-blue-700 bg-blue-50 px-3 py-1 rounded-full font-medium border border-blue-100">
                      {record.answerText}
                    </div>
                  </td>
                  <td className="px-6 py-5 text-sm text-slate-600 align-top">
                    {record.action ? (
                      <div className="bg-amber-50 text-amber-900 p-3 rounded-xl border border-amber-100 leading-relaxed italic">
                        {record.action}
                      </div>
                    ) : (
                      <span className="text-slate-300 italic">Geen specifieke actie</span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      <div className="flex flex-col sm:flex-row gap-4 no-print">
        <button
          onClick={onReset}
          className="flex-1 py-4 bg-blue-600 text-white rounded-2xl font-bold hover:bg-blue-700 shadow-lg shadow-blue-200 transition-all flex items-center justify-center"
        >
          <svg className="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
          </svg>
          Start Opnieuw
        </button>
        <button
          onClick={() => window.print()}
          className="flex-1 py-4 bg-slate-100 text-slate-700 rounded-2xl font-bold hover:bg-slate-200 transition-all flex items-center justify-center"
        >
          <svg className="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 17h2a2 2 0 002-2v-4a2 2 0 00-2-2H5a2 2 0 00-2 2v4a2 2 0 002 2h2m2 4h6a2 2 0 002-2v-4a2 2 0 00-2-2H9a2 2 0 00-2 2v4a2 2 0 002 2zm8-12V5a2 2 0 00-2-2H9a2 2 0 00-2 2v4h10z" />
          </svg>
          Overzicht Printen
        </button>
      </div>

      <style>{`
        @media print {
          .no-print {
            display: none !important;
          }
          body {
            background-color: white !important;
          }
          main {
            box-shadow: none !important;
            border: none !important;
          }
        }
      `}</style>
    </div>
  );
};

export default SummaryScreen;
