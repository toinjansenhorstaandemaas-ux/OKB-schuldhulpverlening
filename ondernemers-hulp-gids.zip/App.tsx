
import React, { useState } from 'react';
import Layout from './components/Layout';
import ProgressBar from './components/ProgressBar';
import QuestionScreen from './components/QuestionScreen';
import SummaryScreen from './components/SummaryScreen';
import { AppState, AnswerRecord, Option } from './types';
import { QUESTIONNAIRE_DATA } from './constants';

const App: React.FC = () => {
  const [appState, setAppState] = useState<AppState>('START');
  const [currentId, setCurrentId] = useState<number>(1);
  const [history, setHistory] = useState<AnswerRecord[]>([]);
  const [pathStack, setPathStack] = useState<number[]>([]);

  const handleStart = () => {
    setAppState('QUESTIONNAIRE');
    setCurrentId(1);
    setHistory([]);
    setPathStack([]);
  };

  const handleAnswer = (option: Option) => {
    const currentQuestion = QUESTIONNAIRE_DATA[currentId];
    
    // Record the answer
    const record: AnswerRecord = {
      questionId: currentId,
      questionText: currentQuestion.text,
      answerText: option.text,
      action: option.action,
    };

    const newHistory = [...history, record];
    setHistory(newHistory);
    
    // Save current ID to stack for back functionality
    setPathStack([...pathStack, currentId]);

    // Navigate
    const nextId = option.nextQuestionId;
    if (nextId === 'END' || !nextId || !QUESTIONNAIRE_DATA[nextId as number]) {
      setAppState('SUMMARY');
    } else {
      setCurrentId(nextId as number);
    }
  };

  const handleBack = () => {
    if (pathStack.length === 0) return;
    
    const newStack = [...pathStack];
    const previousId = newStack.pop()!;
    
    const newHistory = [...history];
    newHistory.pop();

    setPathStack(newStack);
    setCurrentId(previousId);
    setHistory(newHistory);
  };

  const handleReset = () => {
    setAppState('START');
    setCurrentId(1);
    setHistory([]);
    setPathStack([]);
  };

  return (
    <Layout>
      {appState === 'START' && (
        <div className="p-12 text-center">
          <div className="mb-8 flex justify-center">
            <div className="p-6 bg-blue-50 rounded-full">
              <svg className="w-20 h-20 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
            </div>
          </div>
          <h2 className="text-3xl font-extrabold text-slate-900 mb-4">Start uw Advies-sessie</h2>
          <p className="text-slate-600 mb-10 text-lg leading-relaxed max-w-md mx-auto">
            Hulp nodig bij uw onderneming of schulden? Doorloop onze korte vragenlijst voor een gericht advies en actieplan.
          </p>
          <button
            onClick={handleStart}
            className="w-full py-5 bg-blue-600 text-white rounded-2xl font-bold text-lg hover:bg-blue-700 shadow-xl shadow-blue-200 transition-all transform hover:-translate-y-1"
          >
            Start de Vragenlijst
          </button>
          <p className="mt-6 text-slate-400 text-sm italic">Duurt ongeveer 3-5 minuten.</p>
        </div>
      )}

      {appState === 'QUESTIONNAIRE' && (
        <>
          <ProgressBar currentId={currentId} />
          <QuestionScreen
            question={QUESTIONNAIRE_DATA[currentId]}
            onAnswer={handleAnswer}
            onBack={handleBack}
            canGoBack={pathStack.length > 0}
          />
        </>
      )}

      {appState === 'SUMMARY' && (
        <SummaryScreen history={history} onReset={handleReset} />
      )}
    </Layout>
  );
};

export default App;
