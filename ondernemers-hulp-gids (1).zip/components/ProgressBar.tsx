
import React from 'react';

interface ProgressBarProps {
  currentId: number;
}

const ProgressBar: React.FC<ProgressBarProps> = ({ currentId }) => {
  // Rough progress estimate as questionnaire is branching
  const maxEstimated = 23;
  const percentage = Math.min(Math.round((currentId / maxEstimated) * 100), 100);

  return (
    <div className="w-full bg-slate-100 h-2">
      <div 
        className="bg-blue-500 h-full transition-all duration-500 ease-out" 
        style={{ width: `${percentage}%` }}
      />
    </div>
  );
};

export default ProgressBar;
