
export interface Option {
  id: string;
  text: string;
  nextQuestionId: number | string | null;
  action?: string;
}

export interface Question {
  id: number;
  text: string;
  options: Option[];
}

export interface AnswerRecord {
  questionId: number;
  questionText: string;
  answerText: string;
  action?: string;
}

export type AppState = 'START' | 'QUESTIONNAIRE' | 'SUMMARY';
